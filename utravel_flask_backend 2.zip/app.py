import os
from datetime import datetime, timedelta, timezone
from functools import wraps
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from flask_cors import CORS
from flask_restx import Api, Resource, fields
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import func

db = SQLAlchemy()
jwt = JWTManager()

def create_app():
    app = Flask(__name__)
    app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL", "sqlite:///utravel.db")
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["JWT_SECRET_KEY"] = os.getenv("JWT_SECRET_KEY", "CHANGE-THIS-SECRET-IN-PRODUCTION")
    app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(hours=12)
    db.init_app(app); jwt.init_app(app); CORS(app)
    api = Api(app, version="1.0", title="uTravel API", description="uTravel adventure platform backend", doc="/docs")

    class User(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        name = db.Column(db.String(120), nullable=False)
        email = db.Column(db.String(180), unique=True, nullable=False, index=True)
        password_hash = db.Column(db.String(255), nullable=False)
        role = db.Column(db.String(20), default="user", nullable=False)
        city = db.Column(db.String(100), default="Tashkent")
        coins = db.Column(db.Integer, default=0)
        created_at = db.Column(db.DateTime, default=datetime.utcnow)
        def public(self):
            return {"id":self.id,"name":self.name,"email":self.email,"role":self.role,"city":self.city,"coins":self.coins,"created_at":self.created_at.isoformat()}

    class Place(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        slug = db.Column(db.String(100), unique=True, nullable=False)
        name = db.Column(db.String(180), nullable=False)
        region = db.Column(db.String(120), default="")
        description = db.Column(db.Text, default="")
        latitude = db.Column(db.Float)
        longitude = db.Column(db.Float)
        elevation_m = db.Column(db.Integer, default=0)
        difficulty = db.Column(db.String(20), default="easy")
        status = db.Column(db.String(30), default="open")
        is_published = db.Column(db.Boolean, default=True)
        created_at = db.Column(db.DateTime, default=datetime.utcnow)
        def public(self):
            return {k:getattr(self,k) for k in ("id","slug","name","region","description","latitude","longitude","elevation_m","difficulty","status","is_published")}

    class Tour(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        slug = db.Column(db.String(120), unique=True, nullable=False)
        title = db.Column(db.String(180), nullable=False)
        description = db.Column(db.Text, default="")
        region = db.Column(db.String(120), default="")
        difficulty = db.Column(db.String(20), default="moderate")
        starts_at = db.Column(db.DateTime, nullable=False)
        days = db.Column(db.Integer, default=1)
        price_uzs = db.Column(db.Integer, nullable=False)
        seats_total = db.Column(db.Integer, nullable=False)
        seats_left = db.Column(db.Integer, nullable=False)
        is_published = db.Column(db.Boolean, default=True)
        created_at = db.Column(db.DateTime, default=datetime.utcnow)
        def public(self):
            return {k:(getattr(self,k).isoformat() if isinstance(getattr(self,k),datetime) else getattr(self,k)) for k in ("id","slug","title","description","region","difficulty","starts_at","days","price_uzs","seats_total","seats_left","is_published")}

    class Booking(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
        tour_id = db.Column(db.Integer, db.ForeignKey("tour.id"), nullable=False)
        seats = db.Column(db.Integer, default=1)
        total_uzs = db.Column(db.Integer, nullable=False)
        status = db.Column(db.String(30), default="confirmed")
        created_at = db.Column(db.DateTime, default=datetime.utcnow)
        user = db.relationship(User)
        tour = db.relationship(Tour)
        def public(self):
            return {"id":self.id,"user_id":self.user_id,"user_name":self.user.name,"tour_id":self.tour_id,"tour_title":self.tour.title,"seats":self.seats,"total_uzs":self.total_uzs,"status":self.status,"created_at":self.created_at.isoformat()}

    class Post(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
        place_id = db.Column(db.Integer, db.ForeignKey("place.id"), nullable=True)
        caption = db.Column(db.Text, nullable=False)
        photo_url = db.Column(db.String(500), default="")
        likes = db.Column(db.Integer, default=0)
        is_published = db.Column(db.Boolean, default=True)
        created_at = db.Column(db.DateTime, default=datetime.utcnow)
        user = db.relationship(User); place = db.relationship(Place)
        def public(self):
            return {"id":self.id,"user_id":self.user_id,"author":self.user.name,"place_id":self.place_id,"place":self.place.name if self.place else None,"caption":self.caption,"photo_url":self.photo_url,"likes":self.likes,"is_published":self.is_published,"created_at":self.created_at.isoformat()}

    class Checkin(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
        place_id = db.Column(db.Integer, db.ForeignKey("place.id"), nullable=False)
        coins_awarded = db.Column(db.Integer, default=50)
        created_at = db.Column(db.DateTime, default=datetime.utcnow)
        user = db.relationship(User); place = db.relationship(Place)
        def public(self):
            return {"id":self.id,"user_id":self.user_id,"place_id":self.place_id,"place":self.place.name,"coins_awarded":self.coins_awarded,"created_at":self.created_at.isoformat()}

    class Reward(db.Model):
        id = db.Column(db.Integer, primary_key=True)
        title = db.Column(db.String(180), nullable=False)
        partner = db.Column(db.String(160), default="")
        description = db.Column(db.Text, default="")
        cost_coins = db.Column(db.Integer, nullable=False)
        stock = db.Column(db.Integer, default=0)
        is_published = db.Column(db.Boolean, default=True)
        def public(self):
            return {k:getattr(self,k) for k in ("id","title","partner","description","cost_coins","stock","is_published")}

    def current_user():
        ident = get_jwt_identity()
        return db.session.get(User, int(ident)) if ident else None
    def admin_required(fn):
        @wraps(fn)
        @jwt_required()
        def wrapper(*args, **kwargs):
            user=current_user()
            if not user or user.role != "admin": return {"message":"Admin access required"},403
            return fn(*args, **kwargs)
        return wrapper
    def payload(): return request.get_json(silent=True) or {}
    def missing(data, *keys): return [k for k in keys if data.get(k) is None or data.get(k)==""]
    def parse_dt(value):
        if not value: return None
        try: return datetime.fromisoformat(value.replace("Z","+00:00")).replace(tzinfo=None)
        except ValueError: return None

    auth_ns=api.namespace("auth", description="Registration and login")
    public_ns=api.namespace("api", description="Public application API")
    admin_ns=api.namespace("admin", description="Protected admin API")
    auth_model=api.model("Credentials", {"name":fields.String,"email":fields.String(required=True),"password":fields.String(required=True),"city":fields.String})
    @auth_ns.route("/register")
    class Register(Resource):
        @auth_ns.expect(auth_model)
        def post(self):
            d=payload()
            if missing(d,"name","email","password"): return {"message":"name, email and password are required"},400
            if len(d["password"])<8: return {"message":"Password must be at least 8 characters"},400
            email=d["email"].strip().lower()
            if User.query.filter_by(email=email).first(): return {"message":"Email already registered"},409
            u=User(name=d["name"].strip(),email=email,password_hash=generate_password_hash(d["password"]),city=d.get("city","Tashkent"))
            db.session.add(u); db.session.commit()
            return {"user":u.public(),"access_token":create_access_token(identity=str(u.id))},201
    @auth_ns.route("/login")
    class Login(Resource):
        @auth_ns.expect(auth_model)
        def post(self):
            d=payload(); u=User.query.filter_by(email=(d.get("email","").strip().lower())).first()
            if not u or not check_password_hash(u.password_hash,d.get("password","")): return {"message":"Invalid email or password"},401
            return {"user":u.public(),"access_token":create_access_token(identity=str(u.id))}
    @auth_ns.route("/me")
    class Me(Resource):
        @jwt_required()
        def get(self):
            u=current_user()
            if not u: return {"message":"User not found"},404
            return u.public()

    @public_ns.route("/places")
    class Places(Resource):
        def get(self):
            q=Place.query.filter_by(is_published=True)
            if request.args.get("region"): q=q.filter(Place.region.ilike(f"%{request.args['region']}%"))
            if request.args.get("difficulty"): q=q.filter_by(difficulty=request.args["difficulty"])
            if request.args.get("status"): q=q.filter_by(status=request.args["status"])
            return {"items":[x.public() for x in q.order_by(Place.name).all()]}
        @jwt_required()
        def post(self):
            d=payload()
            if missing(d,"slug","name"): return {"message":"slug and name are required"},400
            p=Place(**{k:d[k] for k in ("slug","name","region","description","latitude","longitude","elevation_m","difficulty","status") if k in d})
            db.session.add(p); db.session.commit(); return p.public(),201
    @public_ns.route("/places/<int:item_id>")
    class PlaceDetail(Resource):
        def get(self, item_id):
            p=db.session.get(Place,item_id)
            if not p or not p.is_published:return {"message":"Place not found"},404
            return p.public()

    @public_ns.route("/tours")
    class Tours(Resource):
        def get(self):
            q=Tour.query.filter_by(is_published=True)
            if request.args.get("difficulty"):q=q.filter_by(difficulty=request.args["difficulty"])
            if request.args.get("region"):q=q.filter(Tour.region.ilike(f"%{request.args['region']}%"))
            return {"items":[x.public() for x in q.order_by(Tour.starts_at).all()]}
    @public_ns.route("/tours/<int:item_id>")
    class TourDetail(Resource):
        def get(self, item_id):
            t=db.session.get(Tour,item_id)
            if not t or not t.is_published:return {"message":"Tour not found"},404
            return t.public()

    @public_ns.route("/bookings")
    class Bookings(Resource):
        @jwt_required()
        def get(self):
            u=current_user()
            q=Booking.query if u.role=="admin" else Booking.query.filter_by(user_id=u.id)
            return {"items":[x.public() for x in q.order_by(Booking.created_at.desc()).all()]}
        @jwt_required()
        def post(self):
            d=payload(); u=current_user()
            if missing(d,"tour_id"):return {"message":"tour_id is required"},400
            t=db.session.get(Tour,d["tour_id"]); seats=d.get("seats",1)
            if not t or not t.is_published:return {"message":"Tour not found"},404
            if not isinstance(seats,int) or seats<1:return {"message":"seats must be a positive integer"},400
            if t.seats_left<seats:return {"message":"Not enough seats available"},409
            t.seats_left-=seats
            b=Booking(user_id=u.id,tour_id=t.id,seats=seats,total_uzs=t.price_uzs*seats)
            db.session.add(b);db.session.commit();return b.public(),201
    @public_ns.route("/posts")
    class Posts(Resource):
        def get(self):
            q=Post.query.filter_by(is_published=True).order_by(Post.created_at.desc())
            return {"items":[x.public() for x in q.limit(min(request.args.get("limit",50,type=int),100)).all()]}
        @jwt_required()
        def post(self):
            d=payload()
            if missing(d,"caption"):return {"message":"caption is required"},400
            p=Post(user_id=current_user().id,place_id=d.get("place_id"),caption=d["caption"],photo_url=d.get("photo_url",""))
            db.session.add(p);db.session.commit();return p.public(),201
    @public_ns.route("/posts/<int:item_id>/like")
    class LikePost(Resource):
        @jwt_required()
        def post(self, item_id):
            p=db.session.get(Post,item_id)
            if not p or not p.is_published:return {"message":"Post not found"},404
            p.likes+=1;db.session.commit();return {"id":p.id,"likes":p.likes}
    @public_ns.route("/checkins")
    class Checkins(Resource):
        @jwt_required()
        def get(self):
            return {"items":[x.public() for x in Checkin.query.filter_by(user_id=current_user().id).order_by(Checkin.created_at.desc()).all()]}
        @jwt_required()
        def post(self):
            d=payload();u=current_user()
            if missing(d,"place_id"):return {"message":"place_id is required"},400
            p=db.session.get(Place,d["place_id"])
            if not p or not p.is_published:return {"message":"Place not found"},404
            # Demo backend awards coins after a check-in; production should validate GPS server-side.
            c=Checkin(user_id=u.id,place_id=p.id,coins_awarded=50);u.coins+=50
            db.session.add(c);db.session.commit();return {"checkin":c.public(),"coins":u.coins},201
    @public_ns.route("/rewards")
    class Rewards(Resource):
        def get(self): return {"items":[r.public() for r in Reward.query.filter_by(is_published=True).order_by(Reward.cost_coins).all()]}
    @public_ns.route("/rewards/<int:item_id>/redeem")
    class Redeem(Resource):
        @jwt_required()
        def post(self, item_id):
            r=db.session.get(Reward,item_id);u=current_user()
            if not r or not r.is_published:return {"message":"Reward not found"},404
            if r.stock<1:return {"message":"Reward out of stock"},409
            if u.coins<r.cost_coins:return {"message":"Not enough coins"},409
            u.coins-=r.cost_coins;r.stock-=1;db.session.commit()
            return {"message":"Reward redeemed","remaining_coins":u.coins,"reward":r.public()}

    # Admin CRUD helpers: /admin/{places,tours,rewards,users,bookings,posts}
    def admin_collection(ns, model, serializer, create_fields, editable_fields, search_field=None):
        @ns.route("")
        class Collection(Resource):
            @admin_required
            def get(self):
                q=model.query
                term=request.args.get("q")
                if term and search_field:q=q.filter(getattr(model,search_field).ilike(f"%{term}%"))
                page=max(1,request.args.get("page",1,type=int)); per_page=min(100,max(1,request.args.get("per_page",20,type=int)))
                pagination=q.order_by(model.id.desc()).paginate(page=page,per_page=per_page,error_out=False)
                return {"items":[serializer(x) for x in pagination.items],"pagination":{"page":page,"per_page":per_page,"total":pagination.total,"pages":pagination.pages}}
            @admin_required
            def post(self):
                d=payload(); miss=missing(d,*create_fields)
                if miss:return {"message":"Required fields missing","fields":miss},400
                try:
                    obj=model(**{k:d[k] for k in editable_fields if k in d})
                    db.session.add(obj);db.session.commit();return serializer(obj),201
                except Exception as e:
                    db.session.rollback();return {"message":"Could not create record; check field values and unique constraints"},400
        @ns.route("/<int:item_id>")
        class Item(Resource):
            @admin_required
            def get(self, item_id):
                obj=db.session.get(model,item_id)
                return (serializer(obj),200) if obj else ({"message":"Not found"},404)
            @admin_required
            def patch(self, item_id):
                obj=db.session.get(model,item_id)
                if not obj:return {"message":"Not found"},404
                d=payload()
                for k in editable_fields:
                    if k in d and k not in ("id","password_hash"):setattr(obj,k,d[k])
                db.session.commit();return serializer(obj)
            @admin_required
            def delete(self, item_id):
                obj=db.session.get(model,item_id)
                if not obj:return {"message":"Not found"},404
                db.session.delete(obj);db.session.commit();return {"message":"Deleted"}
    admin_collection(api.namespace("admin/places",description="Admin: places"),Place,lambda x:x.public(),["slug","name"],["slug","name","region","description","latitude","longitude","elevation_m","difficulty","status","is_published"],"name")
    admin_collection(api.namespace("admin/tours",description="Admin: tours"),Tour,lambda x:x.public(),["slug","title","starts_at","price_uzs","seats_total","seats_left"],["slug","title","description","region","difficulty","starts_at","days","price_uzs","seats_total","seats_left","is_published"],"title")
    admin_collection(api.namespace("admin/rewards",description="Admin: rewards"),Reward,lambda x:x.public(),["title","cost_coins"],["title","partner","description","cost_coins","stock","is_published"],"title")
    admin_collection(api.namespace("admin/posts",description="Admin: posts"),Post,lambda x:x.public(),["user_id","caption"],["user_id","place_id","caption","photo_url","likes","is_published"],"caption")

    users_ns=api.namespace("admin/users",description="Admin: users")
    @users_ns.route("")
    class AdminUsers(Resource):
        @admin_required
        def get(self):
            q=User.query
            term=request.args.get("q")
            if term:q=q.filter(db.or_(User.name.ilike(f"%{term}%"),User.email.ilike(f"%{term}%")))
            return {"items":[u.public() for u in q.order_by(User.id.desc()).all()]}
    @users_ns.route("/<int:item_id>")
    class AdminUser(Resource):
        @admin_required
        def patch(self, item_id):
            u=db.session.get(User,item_id)
            if not u:return {"message":"Not found"},404
            d=payload()
            if "role" in d and d["role"] in ("user","admin"):u.role=d["role"]
            if "city" in d:u.city=d["city"]
            if "name" in d:u.name=d["name"]
            db.session.commit();return u.public()
        @admin_required
        def delete(self, item_id):
            u=db.session.get(User,item_id)
            if not u:return {"message":"Not found"},404
            if u.id==current_user().id:return {"message":"You cannot delete your own admin account"},400
            db.session.delete(u);db.session.commit();return {"message":"Deleted"}

    @admin_ns.route("/dashboard")
    class Dashboard(Resource):
        @admin_required
        def get(self):
            return {"users":User.query.count(),"places":Place.query.count(),"tours":Tour.query.count(),"bookings":Booking.query.count(),"posts":Post.query.count(),"revenue_uzs":db.session.query(func.coalesce(func.sum(Booking.total_uzs),0)).filter_by(status="confirmed").scalar(),"recent_bookings":[b.public() for b in Booking.query.order_by(Booking.created_at.desc()).limit(5).all()]}
    @admin_ns.route("/bookings")
    class AdminBookings(Resource):
        @admin_required
        def get(self):
            return {"items":[b.public() for b in Booking.query.order_by(Booking.created_at.desc()).all()]}
    @admin_ns.route("/bookings/<int:item_id>")
    class AdminBooking(Resource):
        @admin_required
        def patch(self, item_id):
            b=db.session.get(Booking,item_id)
            if not b:return {"message":"Not found"},404
            d=payload()
            if d.get("status") in ("confirmed","cancelled","completed"):
                if b.status!="cancelled" and d["status"]=="cancelled":b.tour.seats_left=min(b.tour.seats_total,b.tour.seats_left+b.seats)
                elif b.status=="cancelled" and d["status"]=="confirmed":
                    if b.tour.seats_left<b.seats:return {"message":"Not enough seats"},409
                    b.tour.seats_left-=b.seats
                b.status=d["status"]
            db.session.commit();return b.public()

    @app.get("/health")
    def health(): return {"status":"ok","service":"uTravel Flask API"}
    with app.app_context():
        db.create_all()
        # Optional bootstrap admin; configure ADMIN_EMAIL and ADMIN_PASSWORD before first run.
        email=os.getenv("ADMIN_EMAIL"); password=os.getenv("ADMIN_PASSWORD")
        if email and password and not User.query.filter_by(email=email.lower()).first():
            db.session.add(User(name="Administrator",email=email.lower(),password_hash=generate_password_hash(password),role="admin"))
            db.session.commit()
    return app

app=create_app()
if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.getenv("PORT","5000")),debug=os.getenv("FLASK_DEBUG")=="1")
