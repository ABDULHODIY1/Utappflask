# uTravel Flask Backend

Flask REST API for the uploaded uTravel frontend prototype. Swagger UI is available at `/docs`; no separate admin frontend is included. Admin functionality is exposed only as protected API endpoints.

## Features
- JWT registration, login, current user
- Places and tours catalog
- Tour bookings with seat availability and totals
- Community posts and likes
- Check-ins and coin wallet
- Rewards redemption
- Admin dashboard and protected CRUD APIs for places, tours, rewards, posts, users, and bookings
- SQLite by default; `DATABASE_URL` can be replaced with a PostgreSQL URL
- Pagination on admin catalog endpoints

## Run (Windows PowerShell)
```powershell
cd utravel_flask_backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
# Edit .env: set JWT_SECRET_KEY and ADMIN_EMAIL/ADMIN_PASSWORD
python app.py
```
Open `http://127.0.0.1:5000/docs`.

For Windows CMD, activate with `.venv\Scripts\activate.bat`.

## Bootstrap admin
Set `ADMIN_EMAIL` and `ADMIN_PASSWORD` before the first run. The app creates the admin if that email is not already present. Do not use the example password in production.

## Endpoint map
- `POST /auth/register`, `POST /auth/login`, `GET /auth/me`
- `GET /api/places`, `GET /api/places/{id}`
- `GET /api/tours`, `GET /api/tours/{id}`
- `GET/POST /api/bookings` (JWT; users see their own, admins see all)
- `GET/POST /api/posts`, `POST /api/posts/{id}/like`
- `GET/POST /api/checkins`
- `GET /api/rewards`, `POST /api/rewards/{id}/redeem`
- `GET /admin/dashboard`
- `/admin/places`, `/admin/tours`, `/admin/rewards`, `/admin/posts` (GET/POST collection, GET/PATCH/DELETE item)
- `/admin/users` (GET collection; PATCH/DELETE item)
- `/admin/bookings` (GET collection; PATCH item status)

For protected routes, Swagger's Authorize button expects `Bearer <access_token>`.

## Important integration notes
This backend currently starts with an empty database. Import/seed the prototype's fictional demo catalog into the database or create records through Swagger/admin endpoints. The uploaded frontend currently uses Zustand/localStorage and mock data; to make it use this backend, replace its store/data access with HTTP requests and attach the JWT to protected calls.

GPS check-ins are a prototype implementation: production must validate location, rate-limit check-ins, and prevent duplicate/replayed claims. Payments are not processed here; bookings are recorded as confirmed demo bookings. Before production, add payment-provider callbacks, email verification/password reset, audit logs, migrations, rate limiting, and automated tests.
